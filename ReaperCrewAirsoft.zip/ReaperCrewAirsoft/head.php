<!--<head>
	<meta charset="utf-8">
	<title>Reaper Crew</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<link rel="icon" type="image/png" sizes="32*32" href="image/favicon.png">
</head>-->

<title>Reaper Crew</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" >
<meta name="Content-Language" content="fr">
<meta name="Description" content="Site Officiel de Reaper Crew, Association d'Airsoft">
<meta name="Keywords" content="Reaper, Crew, Airsoft, Club, RCAC, ReaperCrew, Association, Sport, Militaire, Réplique, Loisir, Fuveau, Nomades, Prospect">
<meta name="Subject" content="Airsoft">
<meta name="Author" content="VOLLAIRE Mathis">
<meta name="Publisher" content="VOLLAIRE Mathis">
<meta name="Identifier-Url" content="https://reapercrew-airsoft.fr">
<meta name="Reply-To" content="contact@reapercrew-airsoft.fr">
<meta name="Robots" content="all">
<meta name="Rating" content="14 years">
<meta name="Distribution" content="global">
<meta name="Geography" content="Gardanne, FRANCE">
<meta name="Category" content="sports">
<meta name="DC.Title" content="Reaper Crew">
<meta name="DC.Content-Type" content="UTF-8">
<meta name="DC.Content-Language" content="fr">
<meta name="DC.Description" content="Site Officiel de Reaper Crew, Association d'Airsoft">
<meta name="DC.Keywords" content="Reaper, Crew, Airsoft, Club, RCAC, ReaperCrew, Association, Sport, Militaire, Réplique, Loisir, Fuveau, Nomades, Prospect">
<meta name="DC.Subject" content="Airsoft">
<meta name="DC.Author" content="VOLLAIRE Mathis">
<meta name="DC.Publisher" content="VOLLAIRE Mathis">
<meta name="DC.Identifier-Url" content="https://reapercrew-airsoft.fr">
<meta name="DC.Reply-To" content="contact@reapercrew-airsoft.fr">

<link rel="shortcut icon" type="image/png" href="image/favicon.png"/>
<link rel="canonical" href="https://reapercrew-airsoft.fr/index.html" />
<link rel="stylesheet" media="(min-width: 1000px)" href="computer.css" />
<link rel="stylesheet" media="(max-width: 999px)" href="smartphone.css" />