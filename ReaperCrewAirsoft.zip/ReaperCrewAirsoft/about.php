<!DOCTYPE html>
<html lang="fr">
    <head><?php include("head.php"); ?></head>
    <body><?php include("header.php"); ?>
    
    <section>
        <div class="text_presentation">
            <p class="title_presentation">Historique et création:</p>
            <p>
                L’airsoft est à sa manière une conséquence de la mise en place de la nouvelle constitution du Japon en 1946, et plus exactement de l’article 9 de ladite constitution.
                <br>
                <br>
                À la suite de celle-ci, un certain nombre de lois passèrent pour limiter la détention d’armes sur le sol Japonais. Ce sont les collectionneurs d’armes qui les premiers eurent l’idée de faire des maquettes d’armes réelles, au début non-fonctionnelles, dans les années 70. Un système de piston   couplé à un ressort que l’on compresse manuellement permit non seulement à ces collectionneurs d’en admirer le côté esthétique mais en plus de jouer avec seul ou entre amis en tirant de petites billes de 6 mm de diamètre en plastique.
                <br>
                Par la suite, dans les années 80, le système de compression par engrenage électrique fut inventé. Ce nouveau système et les nouvelles répliques créées grâce à celui-ci donnèrent un nouvel essor à l’activité qui commença alors à s’exporter. C’est dans le milieu des années 80 qu’apparurent les premières répliques airsoft sur le territoire Français.
                <br>
                D’abord cantonné à un public de connaisseur, le succès alla grandissant jusqu’à aujourd’hui où environ 20 000 personnes jouent régulièrement à ce jeu d’enfant réservé aux adultes.
            </p>
            <br>
            <br>

            <p class="title_presentation">Qu’est-ce qu’une réplique d’Airsoft en France ?</p>
            <p>
                Il s’agit d’un objet ayant l’apparence d’une arme à feu susceptible d’expulser un projectile rigide non métallique avec une énergie à la bouche inférieure à 2 joules.
                <br><br>
                D’après l’article R311-1 du Code de la Sécurité Intérieur, ce n’est pas une arme au sens de la loi française :<br>
                Arme factice : objet ayant l’apparence d’une arme à feu susceptible d’expulser un projectile non métallique avec une énergie à la bouche inférieure à 2 joules ;<br>
                Ne sont pas des armes au sens du présent décret les objets tirant un projectile ou projetant des gaz lorsqu’ils développent à la bouche une énergie inférieure à 2 joules.<br><br>
                La commercialisation de ces objets est réglementée par le décret 99-240 qui interdit la vente aux mineurs des répliques de plus de 0.08 joule et jusqu’à 2 joules.
            </p>
            <br><br>

            <p class="title_presentation">Qu’est-ce que l’Airsoft ?</p>
            <p>
                <b>L’Airsoft :</b> 
                <i>(Nom Masculin)</i> 
                désigne toutes les activités légales, sportives ou de loisirs, mettant en œuvre ou en scène des répliques d’Airsoft.<br><br>
                <b>Réplique d’Airsoft :</b> 
                Objet ayant l’apparence d’une arme à feu susceptible d’expulser un projectile rigide non métallique avec une énergie à la bouche inférieure à 2 joules.
            </p>
            <br><br>

            <p class="title_presentation">Airsoft Sportif</p>
            <p>
                L’Airsoft Sportif désigne l’ensemble des pratiques d’Airsoft en équipe ou individuelle qui, à travers une participation organisée, ont pour objectif l’expression ou l’amélioration de la condition physique et psychique, le développement des relations sociales ou l’obtention de résultats en compétition de tous niveaux et la recherche de performances. Ces pratiques sont strictement encadrées par la Fédération Française d’Airsoft conformément à ses statuts.
            </p>
            <br><br>

            <p class="title_presentation">Airsoft Loisir</p>
            <p>
                L’Airsoft Loisir correspond à une activité ludique réunissant une ou plusieurs personnes qui utilisent les répliques d’airsoft. Cette activité peut se présenter sous plusieurs aspects très différents incluant selon les pratiquants une part de jeu de rôle, de jeu de simulation de combat ou simplement du tir sur cible.<br>
                L’aspect le plus commun est une opposition de deux équipes constituées dont les joueurs essayent de s’éliminer mutuellement en se touchant avec les projectiles tirés par les répliques d’airsoft.<br><br>
                Que ce soit l’airsoft sportif ou de loisir, tous deux sont encadrés par les réglementations édictées par la Fédération Française d’Airsoft. Elles doivent impérativement être pratiquées avec les répliques d’airsoft telles que définies par la loi ( R311-1 du Code de la Sécurité Intérieur et Décret 99-240) et obligatoirement avec des lunettes de protection oculaire correspondant à la norme EN166.
            </p>
            <br><br>

            <p class="title_presentation">Où se déroule l’airsoft ?</p>
            <p>
                Le jeu d’airsoft se pratique sur des terrains dûment autorisés par leur propriétaire. Ce peut être un bois ou une forêt, un immeuble ou un terrain bâti recouvert de plusieurs bâtiments.<br>
                Conformément à la loi sur le maintien de la sécurité publique et de l’ordre public et pour des raisons évidentes de sécurité, il ne peut se pratiquer sur la voie publique ou sur les propriétés privées ouvertes au public (commerces, zones commerciales, parcs et jardins publics, monuments, parcs d’attraction, etc.)
            </p>
            <br><br>

            <p class="title_presentation">Qui pratique l’airsoft ?</p>
            <p>
                Toute personne légalement utilisatrice d’une réplique d’airsoft, pratiquant l’activité selon les critères ci-dessus est appelée communément “airsofteur”.
            </p>
            <br><br>

            <p class="BIGtitle_presentation">Comment y joue-t-on ?</p>

            <p class="title_presentation">Airsoft Sportif</p>
            <p>
                La pratique de l’airsoft sportif se doit de répondre à un règlement strict. En effet, celui-ci établit les règles de la discipline de manière à homogénéiser la pratique sur tout le territoire et ainsi faire des compétitions.<br>
                Différentes disciplines, individuelles ou par équipe, sont répertoriées. Il existe notamment le tir sur cibles, la capture de drapeau etc…<br>
                Pour plus d’informations sur l’airsoft sportif, n’hésitez pas à nous contacter
            </p>
            <br><br>

            <p class="title_presentation">Airsoft Loisir</p>
            <p>
                Cette pratique, la plus répandue aujourd’hui, consiste à opposer sur un terrain balisé deux équipes qui vont suivre un scénario et des règles définis par les organisateurs.<br><br>
                Ces règles peuvent être aussi simples que “1 touche = 1 sortie jeu” ou plus compliquées avec des règles de soin en fonction de la partie du corps touchée par la bille.<br>
                Les buts sont, eux, aussi variés que l’imagination des joueurs. On peut selon les cas devoir tout simplement sortir tous les joueurs adverses ou bien avoir à infiltrer une base et en ressortir un objet ou une personne.<br>
                Reste LE point commun à tous : le fairplay.<br>
                En effet aucun marqueur physique n’existant en airsoft, c’est le joueur qui sent la touche qui va se déclarer « out ».
            </p>
            <br>
            
            <p>
                <a href="https://ffairsoft.org/decouvrir-lairsoft/">@ffairsoft - découvrir l'airsoft</a>
            </p>
        </div>
    </section>
    <section>
        <div class="club">
            <div class="text_presentation_RCAC">
                <p class="title_presentation">Le club Reaper Crew</p>
                <p>
                    En 2018, 3 meilleurs amis ont décidé de partager leur passion commune pour l'Airsoft.<br>
                    Leur pari, initier leurs amis communs et organiser des parties où règnent amitié et amusement. Le bouche-à-oreille a permis à de nombreux jeunes de se joindre à eux, et de découvrir une activité à la fois sportive et ludique.<br>
                    Le club a vu son expansion progresser, partant d'un groupe de potes à un regroupement intercommunal. Certains membres venaient de plus d'une vingtaine de kilomètres dans le simple but de retrouver leurs amis et de jouer avec eux.
                </p>
                <br><br>
                <p class="title_presentation">L'association Reaper Crew</p>
                <p>
                    En 2020, ces mêmes amis se sont rendus compte que leur passion était toujours, qu'elle avait un grand potentiel à venir.<br>
                    Les membres majeurs et les plus investis se sont donc lancé le projet de créer une association, dont les principaux objectifs sont de promouvoir, développer, informer et initier à la pratique de l’Airsoft de manière légale, responsable et sécuritaire.
                    Un pari dont ils sont fiers de voir la progression chaque jour, et qu'ils ne cesseront de défendre.<br>
                </p>
                <br>
                <p class="SMALLtitle_presentation">Bienvenue chez Reaper Crew Airsoft Club</p>
            </div>
            
            <iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Freapercrewairsoftclub%2Fposts%2F143550580720029" width="500" height="720" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media" class="facebook"></iframe>
        </div>
    </section>
    
<?php include("footer.php"); ?></body></html>