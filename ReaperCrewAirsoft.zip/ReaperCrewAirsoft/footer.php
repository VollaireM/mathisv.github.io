<footer id="callout">
	<div class="commentaire">
		<div class="row">
			<br>
			<!--<h1>N'hésitez pas à nous contacter pour plus d'information dans la section commentaire ou directement par mail !</h1>-->
			<form id="com" action="mailto:contact@reapercrew-airsoft.fr" method="post" enctype="text/plain">
				<p>
					<label for="prenom">Prénom :</label>
				 	: 
					<input id="prenom" type="text" name="prenom" value=" ">
					<br>
					<label for="nom">Nom :</label>
				 	: 
					<input id="nom" type="text" name="nom" value=" " style="margin-left: 18px;">
					<br>
					<label for="sujet" class="raison">Sujet :</label>
					: 
					<select name="sujet" id="raison" style="margin-left: 16px;">
						<option></option>
						<option class="raison" value="Airsoft">Airsoft</option>
						<option class="raison" value="Admin">Admin</option>
						<option class="raison" value="Partie">Opé</option>
						<option class="raison" value="club">Club</option>
						<option class="raison" value="Règles">Règles</option>
						<option class="raison" value="Paiment">Paiment</option>
						<option class="raison" value="Partenariat">Partenariat</option>
						<option class="raison" value="Autre">Autre</option>
					</select>
					<br>
					<textarea name="impression" rows="5" cols="50" placeholder="Exprimez votre avis..."></textarea>
					<br>
					<input type="submit" value="Envoyer">
				</p>
			</form>
		</div>
	</div>
	<div class="modulo">
		<svg class="modulo">
			<line x1="50%" y1="20%" x2="50%" y2="80%" class="svg_footer"></line>
		</svg>
	</div>
	<br>
	<div class="liens">
    	<a class="liens" href="https://www.instagram.com/reapercrewairsoftclub/" target="_BLANK">
    		<img src="image/lien/instagram.png"> 
       		Instagram 
       		<!--<adress class="computer"> : reapercrewairsoftclub </adress>-->
    	</a>
        <br>
   		<a class="liens" href="https://www.facebook.com/reapercrewairsoftclub" target="_BLANK">
   			<img src="image/lien/facebook.png"> 
     		Facebook
        	<!--<adress class="computer"> : Reaper Crew Airsoft Club</adress>-->
        </a>
        <br>
        <a class="liens" href="mailto:contact@reapercrew-airsoft.fr" target="_BLANK">
        	<img src="image/lien/gmail.png"> 
        	Mail
        	<!--<adress class="computer"> : contact@reapercrew-airsoft.fr</adress>-->
        </a>
	</div>
	<div class="modulo">
		<svg class="modulo">
			<line x1="50%" y1="20%" x2="50%" y2="80%" class="svg_footer"></line>
		</svg>
	</div>
	<br>
	<div class="trip">
		<a href="https://www.tripadvisor.fr/Attraction_Review-g675388-d21298136-Reviews-Reaper_Crew_Airsoft_Club-Fuveau_Bouches_du_Rhone_Provence_Alpes_Cote_d_Azur.html" target="_BLANK">
			<img src="image/lien/tripadvisor.jpg" class="compte" style="padding: 20px;">
		</a>
	</div>
</footer>