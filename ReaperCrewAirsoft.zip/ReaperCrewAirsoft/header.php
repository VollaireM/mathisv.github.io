<header>
	<div class="momento">
		<button class="drop">Momento</button>
		<div class="menu">
			<a href="https://reapercrew-airsoft.fr/">Accueil</a>
			<a href="https://reapercrew-airsoft.fr/">A Propos</a>
			<a href="https://reapercrew-airsoft.fr/">Mentions Légales</a>
			<a href="https://reapercrew-airsoft.fr/">Status</a>
			<a href="https://reapercrew-airsoft.fr/">Adhésions</a>
			<a href="https://reapercrew-airsoft.fr/">Inscription</a>
			<a href="https://reapercrew-airsoft.fr/">Règles</a>
		</div>
	</div>
	<br>		
	<div class="pageAcceuil">
		<div class="logo">
			<img src="image/logo.png">
		</div>
		<br>
		<div class="clubAirsoft">
			<b><p class="nomClub">REAPER CREW</p></b>
			<b><i>Fear the Grim Reaper</i></b>
		</div>
	</div>
	<!--<div class="momento">
		<button class="drop">Partenaire(s)</button>
		<div class="menu">
			<a href="https://eu-tac.com/"></a>
			<a href="https://reapercrew-airsoft.fr/"></a>
		</div>
	</div>-->		
</header>