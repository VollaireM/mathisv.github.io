<!DOCTYPE html>
<html lang="fr">
    <head><?php include("head.php"); ?></head>
    <body><?php include("header.php"); ?><?php include("nav.php"); ?>

        <section>
            <div class="infos_partie">
                <br>
                <p class="title_section"> MENTIONS LEGALES</p>
                <div style="display: flex;">
                    <p class="mcc">
                        Nom de l'Association : Reaper Crew Airsoft CLUB (RCAC)
                        <br>
                        <br>
                        Directeur de publication : VOLLAIRE Mathis (Secraiteur)
                        <br>
                        <br>
                        Contacts : 
                        <br>
                        Adresse postale : 6 lotissement les jardins du stade, 13710 Fuveau
                        <br>
                        Adresse électronique : contact@reapercrew-airsoft.fr
                    </p>
                    <p class="logo_banniere">
                        <img src="image/logo.png" class="logo_banniere">
                    </p>
                </div>
                    <p>@ReaperCrewAirsoftClub</p>
            </div>
            </br>
        </section>

<?php include("footer.php"); ?></body></html>