<!--<nav class="computer">
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">Accueil</a>
	</p>
	<br>
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">A Propos</a>
	</p>
	<br>
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">Mentions Légales</a>
	</p>
	<br>
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">Status</a>
	</p>
	<br>
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">Adhésions</a>
	</p>
	<br>
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">Inscription</a>
	</p>
	<br>
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">Règles</a>
	</p>
	<br>
	<p class="inscription">
        <a href="https://reapercrew-airsoft.fr/formulaire" class="RIG">Inscription aux parties</a>
    </p>
    <br>
</nav>


<nav class="smartphone">
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">Accueil</a>
	</p>
	<br>
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">A Propos</a>
	</p>
	<br>
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">Mentions Légales</a>
	</p>
	<br>
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">Status</a>
	</p>
	<br>
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">Adhésions</a>
	</p>
	<br>
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">Inscription</a>
	</p>
	<br>
	<p class="menu">
		<a href="https://reapercrew-airsoft.fr/">Règles</a>
	</p>
	<br>
	<p class="inscription">
        <a href="https://reapercrew-airsoft.fr/formulaire" class="RIG">Inscription aux parties</a>
    </p>
    <br>
</nav>-->