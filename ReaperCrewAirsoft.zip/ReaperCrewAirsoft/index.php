<!DOCTYPE html>
<html lang="fr">
    <head><?php include("head.php"); ?></head>
    <body><?php include("header.php"); ?><?php include("nav.php"); ?>

        <!--<div id="diaporama">
        <div class="galeriePhoto">
            <img class="slide" src="image/galerie/rcl.jfif"     alt="logo">
            <img class="slide" src="image/galerie/admin.jpg"    alt="poseEnFile">
            <img class="slide"src="image/galerie/bestOp.jpg"    alt="photoGroupe">
            <img class="slide" src="image/galerie/binome.jpg"   alt="2a2">
            <img class="slide" src="image/galerie/bonnet.jpg"   alt="RusseAustra">
            <img class="slide" src="image/galerie/bush.jpg"     alt="hideDansBush">
            <img class="slide" src="image/galerie/ghilly.jpg"   alt="groupePhoto">
            <img class="slide" src="image/galerie/mado2.jpg"    alt="marqueurRouge">
            <img class="slide" src="image/galerie/mando.jpg"    alt="bo1">
            <img class="slide" src="image/galerie/noel.jpg"     alt="bonnetRouge">
            <img class="slide" src="image/galerie/rdv.jpg"      alt="table">
            <img class="slide" src="image/galerie/snipAlex.jpg" alt="noirBlanc">
            <img class="slide" src="image/galerie/voiture.jpg"  alt="voiture">
            <div class="slides"><img src="image/galerie/rcl.jfif"></div>
            <div class="slides"><img src="image/galerie/admin.jpg"></div>
            <div class="slides"><img src="image/galerie/bestOp.jpg"></div>
            <div class="slides"><img src="image/galerie/binome.jpg"></div>
            <div class="slides"><img src="image/galerie/bonnet.jpg"></div>
            <div class="slides"><img src="image/galerie/bush.jpg"></div>
            <div class="slides"><img src="image/galerie/ghilly.jpg"></div>
            <div class="slides"><img src="image/galerie/mado2.jpg"></div>
            <div class="slides"><img src="image/galerie/mando.jpg"></div>
            <div class="slides"><img src="image/galerie/noel.jpg"></div>
            <div class="slides"><img src="image/galerie/rdv.jpg"></div>
            <div class="slides"><img src="image/galerie/snipAlex.jpg"></div>
            <div class="slides"><img src="image/galerie/voiture.jpg"></div>
        </div>
    </div>-->
    <br>
    <br>
    <section class="information">
        <nav class="documents">
            <p class="menu">
                <a href="https://reapercrew-airsoft.fr/">Accueil</a>
            </p>
            <br>
            <p class="menu">
                <a href="https://reapercrew-airsoft.fr/">A Propos</a>
            </p>
            <br>
            <p class="menu">
                <a href="https://reapercrew-airsoft.fr/">Mentions Légales</a>
            </p>
            <br>
            <p class="menu">
                <a href="https://reapercrew-airsoft.fr/">Status</a>
            </p>
            <br>
            <p class="menu">
                <a href="https://reapercrew-airsoft.fr/">Adhésions</a>
            </p>
            <br>
            <p class="menu">
                <a href="https://reapercrew-airsoft.fr/">Inscription</a>
            </p>
            <br>
            <p class="menu">
                <a href="https://reapercrew-airsoft.fr/">Règles</a>
            </p>
        </nav>
        <div class="infos_partie">
            <div class="texte">
                <br>
                <b><h2 class="title_section" style="font-size: 10vm, color: blue">NO MAN'S LAND</h2></b>
                <div>
                    <img src="image/raba.jpg" style="width: 600px; height: 250px; margin: 25px; display: block; margin-left: auto;  margin-right: auto;">
                </div>
                <p class="mcc">Mes chèrs confrères,</p>
                <br>
                <p class="blablaSection">
                    Depuis le 19 mai 2021 les activités sportives sont ré-otorisés.
                    <br>
                    En revenche, pour des raisons d'élégibilité et juridique, nous avons pris la décision de déserté notre ancien terrain, ce qui fait que pour le moment nous n'avons plus d'endroit où pratiquer l'airsoft.
                    <br>
                    Cela ne signifie pas que nous avons sesser toute activité ! Nous somme toujours actif sur les réseaux sociaux et dans la communication, n'hésitez pas à nous contacter pour plus d'infos via par mail ou dans la section commentaire.
                    <br>
                    Nous sommes impassiant de vous revoir,
                    <br>
                    <p class="footerSection" style="color: red;">A TRES BIENTOT !</p>
                    <br>
                </p>
            </div>
            <div class="texte">
                <br>
                    <b><h3 class="title_section" style="font-size: 10vm, color: blue"> Partie Hebdomadaire</h3></b>
                    <!--<div>
                        <img src="image/raba.jpg" style="width: 600px; height: 250px; margin: 25px; display: block; margin-left: auto;  margin-right: auto;">
                    </div>-->
                    <p class="mcc">Mes chers confreres, </p>
                    <p class="blabla_section">Nous avons le plaisir de vous retrouver dans le cadre d'une partie d'airsoft tous les week-ends !
                        <br>
                        Arrivée souhaitée à partir de <b>9h30</b>
                        <br>
                        Fin de journée aux alentours de <b>17h00</b>
                        <br>
                        <b>Pensez à prendre alimentation et hydratation pour la journée</b>
                        <br>
                        <br>
                        Vous pouvez deja vous inscrire sur le 
                        <a href="https://reapercrew-airsoft.fr/formulaire" onclick="open('formulaire.html', 'Popup', 'scrollbars=1,resizable=1,height=805,width=608'); return false;" class="formulaire_section">Formulaire ci-joint </a>
                        <br>
                    </p>
                    <br>
                </div>
            </div>
        </div>      
    </section>  
    <br>
    <div id="scroll_to_top">
        <a href="#top">
            <img src="image/toTop.jpg" alt="Retourner en haut"/>
        </a>
    </div>
    <br>
    <div id="menuFlottant">
        <p style="font-size: 15px; font-family: unset; color: white; text-align: left;">Partenaire(s) :</p>
        <a href="https://eu-tac.com/" class="sprite lienInsta">
            <img src="image/eutac.png" style="width: 90px;">
        </a>
        <a href="https://minotaurostore.com/">
            <img src="image/minotauro.jpg" style="width: 90px;">
        </a>
    </div>

<?php include("footer.php"); ?></body></html>