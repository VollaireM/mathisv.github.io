<?php

try{
	$bdd = new PDO('mysql:host=reaperrbdd.mysql.db;dbname=reaperrbdd;charset=utf8', 'reaperrbdd', 'Vh013k3e1');}

catch(Exception $e){
        die('Erreur : '.$e->getMessage());}

$req = $bdd->prepare('INSERT INTO Presence(Date, Nom, Prenom, Courriel, Groupe, Presence, Replique, Replique_type, EPI) VALUES(:Date, :Nom, :Prenom, :Courriel, :Groupe, :Presence, :Replique, :Replique_type, :EPI)');

$req->execute(array(
	'Date'		=> $_POST['date'],
	'Nom' 		=> $_POST['nom'],
	'Prenom' 	=> $_POST['prenom'],
	'Courriel' 	=> $_POST['email'],
	'Groupe' 	=> $_POST['groupe'],
    	'Presence' 	=> $_POST['oui_non'],
    	'Replique' 	=> $_POST['replique'],
    	'Replique_type'	=> $_POST['replique_type'],
    	'EPI' 		=> $_POST['epi']));

echo 'Informations envoyées le ', date('d-m-Y H:i');?>

<p>VOTRE INSCRIPTION NOUS A ETE TRANSMISE</p> 
<p>Recapitulatif des donnees transmises : </p>

<p>Date de la partie : <?php echo $_POST['date']; ?></p> 
<p>Votre nom : <?php echo $_POST['nom']; ?></p> 
<p>Votre prenom : <?php echo $_POST['prenom']; ?></p> 
<p>Votre courriel : <?php echo $_POST['email']; ?></p> 
<p>Votre groupe : <?php echo $_POST['groupe']; ?></p> 
<p>Presence : <?php echo $_POST['oui_non']; ?></p> 
<p>Replique : <?php echo $_POST['replique']; ?> 
<?php echo $_POST['replique_type']; ?><p> 
<p>Equipements de Protection Individuels : <?php echo $_POST['epi']; ?></p>
